public class Klient {
    public String imie;
    public String nazwisko;
    public int listaZamowien;

    public Klient(String imie, String nazwisko, int listaZamowien){
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.listaZamowien = listaZamowien;
    }
}
