public class Main {
    public static void main(String[] args) {
        Produkt pierwszy = new Produkt("Arbuz", 6.80, 500);
        Produkt drugi = new Produkt("Brokul", 8.20, 200);
        KoszykZakupowy koszyk = new KoszykZakupowy();
        Zamowienie zamowienie = new Zamowienie(koszyk, "Oczekujące");

        System.out.println(pierwszy.wyswietlInformacje());
        System.out.println(drugi.wyswietlInformacje());
        System.out.println();
        pierwszy.dodajDoMagazynu(10);
        System.out.println(pierwszy.wyswietlInformacje());
        pierwszy.usunZMagazynu(100);
        System.out.println(pierwszy.wyswietlInformacje());
        System.out.println();
        drugi.usunZMagazynu(50);
        System.out.println(drugi.wyswietlInformacje());
        koszyk.DodajProdukt(pierwszy, 5);
        koszyk.DodajProdukt(drugi, 10);
        koszyk.wyswietlZawartoscKoszyka();
        double wynik = koszyk.obliczCalkowitaWartosc();
        System.out.println("Cena calkowita: " + wynik);
        zamowienie.wyswietlZamowienie();
        zamowienie.ustawStatusZamowienia("Zrealizowane");
        zamowienie.wyswietlZamowienie();
    }
}