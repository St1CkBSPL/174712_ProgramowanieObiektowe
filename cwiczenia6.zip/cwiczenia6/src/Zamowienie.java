public class Zamowienie {
    public String statusZamowienia;
    KoszykZakupowy koszyk;

    public Zamowienie(KoszykZakupowy koszyk, String statusZamowienia){
        this.koszyk = koszyk;
        this.statusZamowienia = statusZamowienia;
    }

    public void ustawStatusZamowienia(String nowyStatus){
        this.statusZamowienia = nowyStatus;
        System.out.println("Status zamowienia: " + nowyStatus);
    }
    public void wyswietlZamowienie(){
        System.out.println("Zamowienie: ");
        koszyk.wyswietlZawartoscKoszyka();
        System.out.println("Status zamowienia: " + statusZamowienia);
    }
}
