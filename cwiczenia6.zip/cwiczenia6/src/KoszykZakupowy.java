import java.util.ArrayList;

public class KoszykZakupowy {
    ArrayList<Produkt> koszyk;

    public KoszykZakupowy(){
        this.koszyk = new ArrayList<>();
    }

    public void DodajProdukt(Produkt produkt, int ilosc){
        if(produkt.iloscNaMagazynie >= ilosc){
            produkt.usunZMagazynu(ilosc);
            koszyk.add(new Produkt(produkt.nazwa, produkt.cena, ilosc));
            System.out.println("Dodano produkt:" + produkt.nazwa + "ilość: " + ilosc);
        }
        else{
            System.out.println("Nie ma wystarczajacej ilosci na magazynie.");
        }
    }
    public void wyswietlZawartoscKoszyka(){
        System.out.println("Zawartosc koszyka: ");
        for(Produkt produkt : koszyk){
            System.out.println(produkt.nazwa + " | ilość: " + produkt.iloscNaMagazynie + " | cena: " + produkt.cena);
        }
    }
    public double obliczCalkowitaWartosc(){
        double wartosc = 0;
        for(Produkt produkt : koszyk){
            wartosc += produkt.cena * produkt.iloscNaMagazynie;
        }
        return wartosc;
    }
}

