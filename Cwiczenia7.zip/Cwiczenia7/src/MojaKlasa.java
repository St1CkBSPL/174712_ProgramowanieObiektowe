public class MojaKlasa {
    public String getKlasa(){
        return "Cześć jestem klasą " + this.getClass().getSimpleName();
    }
}
