public class ProduktSpozywczy extends Produkt {
    public final String Owoc;

    public ProduktSpozywczy(String Owoc){
        this.Owoc = Owoc;
    }

    public String getOwoc(){
        return Owoc;
    }
}