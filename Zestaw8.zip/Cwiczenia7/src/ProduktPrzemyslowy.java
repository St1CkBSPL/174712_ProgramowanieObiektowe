public class ProduktPrzemyslowy extends Produkt {
    public final String Mlotek;

    public ProduktPrzemyslowy(String Mlotek){
        this.Mlotek = Mlotek;
    }

    public String getMlotek(){
        return Mlotek;
    }
}